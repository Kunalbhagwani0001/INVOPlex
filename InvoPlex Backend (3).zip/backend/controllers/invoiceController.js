import { Invoice, Client, BusinessDetail } from '../models/index.js';
import PDFDocument from 'pdfkit';
import path from 'path';
import fs from 'fs';
import nodemailer from 'nodemailer';
import QRCode from 'qrcode';

export const getInvoices = async (req, res) => {
    try {
        const invoices = await Invoice.find({ user: req.user._id }).populate('client').sort({ createdAt: -1 });
        res.json({ data: invoices });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const getInvoice = async (req, res) => {
    try {
        const invoice = await Invoice.findOne({ _id: req.params.id, user: req.user._id }).populate('client');
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
        res.json(invoice);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const createInvoice = async (req, res) => {
    try {
        const { client_id, invoice_date, due_date, items, discount_total, notes, currency } = req.body;
        
        let subtotal = 0;
        let tax_total = 0;
        const processedItems = items.map(item => {
            const itemTotal = item.quantity * item.price;
            subtotal += itemTotal;
            tax_total += itemTotal * (item.tax_percent / 100);
            return {
                ...item,
                total: itemTotal * (1 + item.tax_percent / 100)
            };
        });

        const grand_total = (subtotal + tax_total) - (parseFloat(discount_total) || 0);

        const invoice = await Invoice.create({
            invoice_number: 'INV-' + Math.random().toString(36).substring(2, 10).toUpperCase(),
            invoice_date,
            due_date,
            subtotal,
            tax_total,
            discount_total: discount_total || 0,
            grand_total,
            currency: currency || 'INR',
            notes,
            user: req.user._id,
            client: client_id,
            items: processedItems
        });

        res.status(201).json(invoice);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const updateInvoice = async (req, res) => {
    try {
        const { client_id, invoice_date, due_date, items, discount_total, notes, currency } = req.body;
        
        let subtotal = 0;
        let tax_total = 0;
        const processedItems = items.map(item => {
            const itemTotal = item.quantity * item.price;
            subtotal += itemTotal;
            tax_total += itemTotal * (item.tax_percent / 100);
            return {
                ...item,
                total: itemTotal * (1 + item.tax_percent / 100)
            };
        });

        const grand_total = (subtotal + tax_total) - (parseFloat(discount_total) || 0);

        const invoice = await Invoice.findOneAndUpdate(
            { _id: req.params.id, user: req.user._id },
            {
                client: client_id,
                invoice_date,
                due_date,
                subtotal,
                tax_total,
                discount_total: discount_total || 0,
                grand_total,
                currency: currency || 'INR',
                notes,
                items: processedItems
            },
            { new: true }
        );

        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
        res.json(invoice);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Centralized PDF Generation
const generateInvoicePDF = async (doc, invoice, business) => {
    // Logo
    if (business?.logo_path) {
        const logoPath = path.join(process.cwd(), 'uploads', business.logo_path);
        if (fs.existsSync(logoPath)) {
            doc.image(logoPath, 50, 45, { width: 60 });
        }
    }

    // Company Info
    doc.fillColor('#444444')
       .fontSize(20)
       .font('Helvetica-Bold')
       .text(business?.name || 'Your Company', 120, 50)
       .fontSize(10)
       .font('Helvetica')
       .text(business?.address || '', 120, 75)
       .text(business?.phone ? `Phone: ${business.phone}` : '', 120, 90)
       .text(business?.gst_number ? `GST: ${business.gst_number}` : '', 120, 105);

    // Invoice Header
    doc.fillColor('#000000')
       .fontSize(25)
       .font('Helvetica-Bold')
       .text('INVOICE', 400, 50, { align: 'right' })
       .fontSize(12)
       .font('Helvetica')
       .text(`#${invoice.invoice_number}`, 400, 80, { align: 'right' })
       .text(`Date: ${new Date(invoice.invoice_date).toLocaleDateString()}`, 400, 95, { align: 'right' });

    doc.moveTo(50, 150).lineTo(550, 150).stroke();

    // Bill To
    doc.fontSize(12).font('Helvetica-Bold').text('BILL TO:', 50, 170);
    doc.fontSize(10).font('Helvetica')
       .text(invoice.client.name, 50, 190)
       .text(invoice.client.address || '', 50, 205)
       .text(invoice.client.email || '', 50, 220);

    // Table
    const tableTop = 270;
    doc.font('Helvetica-Bold').fillColor('#333333');
    generateTableRow(doc, tableTop, 'Item Description', 'Qty', 'Price', 'Tax %', 'Total');
    doc.moveTo(50, tableTop + 15).lineTo(550, tableTop + 15).stroke();
    
    let position = tableTop + 25;
    doc.font('Helvetica').fillColor('#000000');
    invoice.items.forEach(item => {
        generateTableRow(doc, position, item.name, item.quantity.toString(), item.price.toString(), item.tax_percent.toString(), item.total.toFixed(2));
        position += 20;
    });

    // Totals
    const totalPos = position + 30;
    doc.moveTo(350, totalPos - 10).lineTo(550, totalPos - 10).stroke();
    doc.text('Subtotal:', 350, totalPos);
    doc.text(`${invoice.currency} ${invoice.subtotal.toFixed(2)}`, 450, totalPos, { align: 'right' });
    doc.text('Tax Total:', 350, totalPos + 15);
    doc.text(`${invoice.currency} ${invoice.tax_total.toFixed(2)}`, 450, totalPos + 15, { align: 'right' });
    
    doc.fontSize(14).font('Helvetica-Bold').fillColor('#4F46E5').text('Grand Total:', 350, totalPos + 40);
    doc.text(`${invoice.currency} ${invoice.grand_total.toFixed(2)}`, 450, totalPos + 40, { align: 'right' });

    // Payment QR
    if (business?.upi_id) {
        const upiLink = `upi://pay?pa=${business.upi_id}&pn=${encodeURIComponent(business.name)}&am=${invoice.grand_total}&tn=${encodeURIComponent('Inv ' + invoice.invoice_number)}&cu=${invoice.currency}`;
        try {
            const qrDataUrl = await QRCode.toDataURL(upiLink);
            doc.moveTo(50, 600).lineTo(550, 600).stroke();
            doc.fontSize(10).font('Helvetica-Bold').fillColor('#000000').text('SCAN TO PAY', 50, 615);
            doc.image(qrDataUrl, 50, 630, { width: 90 });
            doc.fontSize(8).font('Helvetica').fillColor('#4F46E5').text('Payment Link:', 150, 630);
            doc.text(upiLink, 150, 642, { width: 380, underline: true });
        } catch (err) {}
    }

    doc.font('Helvetica').fontSize(10).fillColor('#888888').text('Thank you for your business!', 50, 750, { align: 'center', width: 500 });
};

function generateTableRow(doc, y, item, qty, price, tax, total) {
    doc.fontSize(10)
       .text(item, 50, y, { width: 220 })
       .text(qty, 280, y, { width: 40, align: 'right' })
       .text(price, 330, y, { width: 70, align: 'right' })
       .text(tax, 410, y, { width: 40, align: 'right' })
       .text(total, 480, y, { width: 70, align: 'right' });
}

export const downloadPDF = async (req, res) => {
    try {
        const invoice = await Invoice.findOne({ _id: req.params.id, user: req.user._id }).populate('client');
        const business = await BusinessDetail.findOne({ user: req.user._id });
        const doc = new PDFDocument({ margin: 50 });
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=invoice-${invoice.invoice_number}.pdf`);
        doc.pipe(res);
        await generateInvoicePDF(doc, invoice, business);
        doc.end();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const updateStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const update = { status };
        if (status === 'paid') {
            update.paid_at = new Date();
        } else {
            update.paid_at = null;
        }

        const invoice = await Invoice.findOneAndUpdate(
            { _id: req.params.id, user: req.user._id },
            update,
            { new: true }
        );
        res.json(invoice);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const sendInvoiceEmail = async (req, res) => {
    try {
        const invoice = await Invoice.findOne({ _id: req.params.id, user: req.user._id }).populate('client');
        const business = await BusinessDetail.findOne({ user: req.user._id });
        if (!invoice.client.email) return res.status(400).json({ message: 'Client email missing' });

        // Update status to unpaid as soon as email is initiated
        await Invoice.findByIdAndUpdate(req.params.id, { status: 'unpaid' });

        const tempPath = path.join(process.cwd(), 'uploads', `temp-${invoice._id}.pdf`);
        const doc = new PDFDocument({ margin: 50 });
        const writeStream = fs.createWriteStream(tempPath);
        doc.pipe(writeStream);
        await generateInvoicePDF(doc, invoice, business);
        doc.end();

        // Send immediate response to frontend
        res.json({ message: 'Email sending in progress...' });

        writeStream.on('finish', async () => {
            const transporter = nodemailer.createTransport({
                host: process.env.SMTP_HOST,
                port: process.env.SMTP_PORT,
                secure: true,
                auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
            });

            const billingMonth = new Date(invoice.invoice_date).toLocaleString('default', { month: 'long', year: 'numeric' });
            const paymentLink = `http://localhost:5173/view/${invoice._id}`;

            const htmlContent = `
                <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; color: #1e293b;">
                    <div style="background-color: #4f46e5; padding: 40px 20px; text-align: center; color: white;">
                        <h1 style="margin: 0; font-size: 24px;">New Invoice Received</h1>
                        <p style="margin: 10px 0 0; opacity: 0.9;">Invoice #${invoice.invoice_number}</p>
                    </div>
                    <div style="padding: 40px 30px;">
                        <h2 style="color: #1e293b; margin-top: 0;">Hello ${invoice.client.name},</h2>
                        <p style="line-height: 1.6; color: #64748b;">A new invoice has been generated for your account for the period of <strong>${billingMonth}</strong>.</p>
                        
                        <div style="background-color: #f8fafc; padding: 25px; border-radius: 12px; margin: 30px 0;">
                            <table style="width: 100%; border-collapse: collapse;">
                                <tr>
                                    <td style="padding: 8px 0; color: #64748b;">Amount Due:</td>
                                    <td style="padding: 8px 0; text-align: right; font-weight: bold; font-size: 18px; color: #4f46e5;">${invoice.currency} ${invoice.grand_total.toLocaleString()}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 0; color: #64748b;">Billing Date:</td>
                                    <td style="padding: 8px 0; text-align: right; font-weight: bold;">${new Date(invoice.invoice_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 0; color: #64748b;">Due Date:</td>
                                    <td style="padding: 8px 0; text-align: right; font-weight: bold; color: #ef4444;">${new Date(invoice.due_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}</td>
                                </tr>
                            </table>
                        </div>

                        <div style="text-align: center; margin-top: 40px;">
                            <a href="${paymentLink}" style="background-color: #4f46e5; color: white; padding: 16px 32px; border-radius: 12px; text-decoration: none; font-weight: bold; font-size: 16px; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.4);">Pay Invoice Online</a>
                        </div>
                        
                        <p style="margin-top: 40px; font-size: 13px; color: #94a3b8; text-align: center;">
                            Thank you for your business! If you have any questions, please contact ${business?.name || 'us'}.
                        </p>
                    </div>
                    <div style="background-color: #f1f5f9; padding: 20px; text-align: center; font-size: 12px; color: #94a3b8;">
                        &copy; ${new Date().getFullYear()} ${business?.name || 'InvoicePro'}. All rights reserved.
                    </div>
                </div>
            `;

            try {
                await transporter.sendMail({
                    from: `"${business?.name || 'InvoicePro'}" <${process.env.SMTP_USER}>`,
                    to: invoice.client.email,
                    subject: `Invoice #${invoice.invoice_number} - ${billingMonth} - ${business?.name || 'InvoicePro'}`,
                    html: htmlContent,
                    attachments: [{ filename: `invoice-${invoice.invoice_number}.pdf`, path: tempPath }]
                });
                console.log(`Email sent successfully to ${invoice.client.email}`);
            } catch (err) {
                console.error('SMTP Error:', err);
            } finally {
                if (fs.existsSync(tempPath)) {
                    fs.unlinkSync(tempPath);
                }
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const deleteInvoice = async (req, res) => {
    try {
        const invoice = await Invoice.findOneAndDelete({ _id: req.params.id, user: req.user._id });
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
        res.json({ message: 'Invoice deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const getPublicInvoice = async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id).populate('client');
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
        const business = await BusinessDetail.findOne({ user: invoice.user });
        res.json({ 
            invoice, 
            business,
            razorpay_key: process.env.RAZORPAY_KEY_ID 
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const processPublicPayment = async (req, res) => {
    try {
        const { transaction_id, bank_name, payment_method, payer_name } = req.body;
        const invoice = await Invoice.findByIdAndUpdate(
            req.params.id,
            {
                status: 'paid',
                paid_at: new Date(),
                transaction_id,
                bank_name,
                payment_method,
                notes: `Paid by ${payer_name} via ${bank_name}` // Storing payer details in notes for history
            },
            { new: true }
        );
        res.json({ message: 'Payment confirmed successfully', invoice });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
