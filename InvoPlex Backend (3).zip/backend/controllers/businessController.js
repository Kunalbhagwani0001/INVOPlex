import { BusinessDetail } from '../models/index.js';
import multer from 'multer';
import path from 'path';

// Multer Storage Configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

export const upload = multer({ storage });

export const getBusinessDetails = async (req, res) => {
    try {
        const details = await BusinessDetail.findOne({ user: req.user._id });
        res.json(details || {});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const updateBusinessDetails = async (req, res) => {
    try {
        const updateData = { ...req.body, user: req.user._id };
        
        if (req.file) {
            updateData.logo_path = req.file.filename;
        }

        const details = await BusinessDetail.findOneAndUpdate(
            { user: req.user._id },
            updateData,
            { new: true, upsert: true }
        );
        res.json(details);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
