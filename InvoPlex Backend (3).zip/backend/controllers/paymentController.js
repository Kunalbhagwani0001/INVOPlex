import Razorpay from 'razorpay';
import crypto from 'crypto';
import { Invoice } from '../models/index.js';

export const createRazorpayOrder = async (req, res) => {
    try {
        const razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY_ID,
            key_secret: process.env.RAZORPAY_KEY_SECRET
        });

        const invoice = await Invoice.findById(req.params.id);
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });

        // Safety check for amount
        const amount = Math.round(Number(invoice.grand_total) * 100);
        if (isNaN(amount) || amount <= 0) {
            return res.status(400).json({ message: 'Invalid invoice amount' });
        }

        const options = {
            amount: amount,
            currency: 'INR', // Forced INR for Indian Razorpay accounts
            receipt: `receipt_${invoice.invoice_number}`,
            notes: {
                invoice_number: invoice.invoice_number,
                invoice_id: invoice._id.toString()
            }
        };

        console.log('Creating Razorpay order with options:', options);
        const order = await razorpay.orders.create(options);
        res.json(order);
    } catch (error) {
        console.error('Razorpay Order Error Details:', error);
        res.status(500).json({ message: error.description || error.message || 'Razorpay initialization failed' });
    }
};

export const razorpayWebhook = async (req, res) => {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
    const signature = req.headers['x-razorpay-signature'];

    const shasum = crypto.createHmac('sha256', secret);
    shasum.update(JSON.stringify(req.body));
    const digest = shasum.digest('hex');

    if (digest === signature) {
        // Signature matches
        const event = req.body.event;
        if (event === 'payment.captured') {
            const payment = req.body.payload.payment.entity;
            const orderId = payment.order_id;
            
            // Find invoice with this orderId if you stored it, or use notes
            // For simplicity, Razorpay allows sending notes in order creation
            // We'll update by searching for the amount and receipt if needed
            // But better to store order_id in Invoice model
            
            const invoice = await Invoice.findOneAndUpdate(
                { invoice_number: payment.notes.invoice_number },
                {
                    status: 'paid',
                    paid_at: new Date(),
                    transaction_id: payment.id,
                    bank_name: payment.bank || payment.vpa || 'Razorpay',
                    payment_method: payment.method,
                    notes: `Paid via ${payment.method} (${payment.email})`
                },
                { new: true }
            );
            console.log('Payment captured and invoice updated:', invoice?.invoice_number);
        }
        res.json({ status: 'ok' });
    } else {
        res.status(400).send('Invalid signature');
    }
};
