import mongoose from 'mongoose';

const clientSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String },
    phone: { type: String },
    address: { type: String },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

const businessDetailSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String },
    phone: { type: String },
    address: { type: String },
    gst_number: { type: String },
    logo_path: { type: String },
    upi_id: { type: String },
    currency: { type: String, default: 'INR' },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

const invoiceSchema = new mongoose.Schema({
    invoice_number: { type: String, required: true, unique: true },
    invoice_date: { type: Date, required: true },
    due_date: { type: Date },
    subtotal: { type: Number, default: 0 },
    tax_total: { type: Number, default: 0 },
    discount_total: { type: Number, default: 0 },
    grand_total: { type: Number, default: 0 },
    status: { type: String, default: 'draft' },
    paid_at: { type: Date },
    transaction_id: { type: String },
    payment_method: { type: String },
    bank_name: { type: String },
    currency: { type: String, default: 'INR' },
    notes: { type: String },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    client: { type: mongoose.Schema.Types.ObjectId, ref: 'Client', required: true },
    items: [{
        name: { type: String, required: true },
        quantity: { type: Number, required: true },
        price: { type: Number, required: true },
        tax_percent: { type: Number, default: 0 },
        total: { type: Number, required: true }
    }]
}, { timestamps: true });

export const Client = mongoose.model('Client', clientSchema);
export const BusinessDetail = mongoose.model('BusinessDetail', businessDetailSchema);
export const Invoice = mongoose.model('Invoice', invoiceSchema);
