import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB from './config/db.js';
import { register, login } from './controllers/authController.js';
import { getInvoices, getInvoice, createInvoice, updateInvoice, deleteInvoice, downloadPDF, updateStatus, sendInvoiceEmail, getPublicInvoice, processPublicPayment } from './controllers/invoiceController.js';
import { getClients, createClient, updateClient, deleteClient } from './controllers/clientController.js';
import { getBusinessDetails, updateBusinessDetails, upload } from './controllers/businessController.js';
import { createRazorpayOrder, razorpayWebhook } from './controllers/paymentController.js';
import { protect } from './middleware/authMiddleware.js';

dotenv.config();

// Connect to MongoDB
connectDB();

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Auth Routes
app.post('/api/register', register);
app.post('/api/login', login);

// Invoice Routes
app.get('/api/invoices', protect, getInvoices);
app.get('/api/invoices/:id', protect, getInvoice);
app.post('/api/invoices', protect, createInvoice);
app.put('/api/invoices/:id', protect, updateInvoice);
app.delete('/api/invoices/:id', protect, deleteInvoice);
app.get('/api/invoices/:id/download', protect, downloadPDF);
app.patch('/api/invoices/:id/status', protect, updateStatus);
app.post('/api/invoices/:id/send-email', protect, sendInvoiceEmail);

// Public Routes (For Clients)
app.get('/api/public/invoices/:id', getPublicInvoice);
app.post('/api/public/invoices/:id/pay', processPublicPayment);
app.post('/api/public/invoices/:id/razorpay', createRazorpayOrder);
app.post('/api/webhooks/razorpay', razorpayWebhook);

// Client Routes
app.get('/api/clients', protect, getClients);
app.post('/api/clients', protect, createClient);
app.put('/api/clients/:id', protect, updateClient);
app.delete('/api/clients/:id', protect, deleteClient);

// Business Routes
app.get('/api/business-details', protect, getBusinessDetails);
app.post('/api/business-details', protect, upload.single('logo'), updateBusinessDetails);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});
